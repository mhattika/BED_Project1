package org.greatlearning.tta;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TicketTrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(TicketTrackingApplication.class, args);
	}
}
